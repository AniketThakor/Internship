<?php
 $connection = mysqli_connect("localhost","root","","db_internship");
 

 if(isset($_GET['deleteid']))
{
 mysqli_query($connection, "delete from tbl_user2 where user_id='{$_GET['deleteid']}'") or die(mysqli_error($connection));
 
}

echo "<a href='table.php'>Show Updated</a>";