<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "db_internship";
//Connection Function
$connection = mysqli_connect($host, $username, $password, $dbname);
if($_POST){
            $name = $_POST['name'];
            $fname = $_POST['father_name'];
            $address = $_POST['address'];
            $gender = $_POST['gender'];
            $state = $_POST['state'];
            $city = $_POST['city'];
            $dob = $_POST['birth_date'];
            $pincode = $_POST['pincode'];
            $course = $_POST['course'];
            $email = $_POST['email'];
            $q = mysqli_query($connection,"insert into tbl_student2(st_name,st_fname,st_address,st_gender,st_state,st_city,st_dob,st_pincode,st_course,st_email) values('{$name}','{$fname}','{$address}','{$gender}','{$state}','{$city}','{$dob}','{$pincode}','{$course}','{$email}')")
            or die("Error ". mysqli_error($connection));
            if ($q){
                echo "<script>alert('Record Added');</script>";
                
            }
            
            }

?>
<html>
    <body>
        <form method="post">
             <label for="fname">First name:</label><br>
             <input type="text" id="fname" name="name"><br>
             <label for="lname">Father name:</label><br>
             <input type="text" id="lname" name="father_name"><br>
             <label for="fname">Address:</label><br>
             <input type="text" id="fname" name="address"><br>
             <label for="lname">Gender:</label><br>
             <select name="txt2">
                <option>Male</option>
                <option>Female</option>
            </select><br>
             <label for="fname">State:</label><br>
             <input type="text" id="fname" name="state"><br>            
             <label for="fname">City:</label><br>
             <input type="text" id="fname" name="city"><br>     
             <label for="fname">DOB:</label><br>
             <input type="number" id="fname" name="birth_date"><br>             
             <label for="fname">Pin Code:</label><br>
             <input type="text" id="fname" name="pincode"><br>   
             <label for="fname">Course:</label><br>
             <input type="text" id="fname" name="course"><br>  
             <label for="fname">Email:</label><br>
             <input type="text" id="fname" name="email"><br>              
           
        </form>
        
    </body>
</html>
<a href='Display.php'>Display Record</a>

