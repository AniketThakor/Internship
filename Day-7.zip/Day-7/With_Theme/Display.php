<?php 
	$host = "localhost";
	$username = "root";
	$passwd = "";
	$dbname = "db_internship";

	$connection = mysqli_connect($host, $username, $passwd, $dbname);
        $q = mysqli_query($connection,"select * from tbl_student2")
        or die("Error". mysqli_error($connection));
        
//Query
echo "<table border='1'>";
echo "<tr>";
echo "<th>No.</th>";
echo "<th>First Name</th>";
echo "<th>Father's name</th>";
echo "<th>Address</th>";
echo "<th>Gender</th>";
echo "<th>State</th>";
echo "<th>City</th>";
echo "<th>DOB</th>";
echo "<th>Pincode</th>";
echo "<th>COurse</th>";
echo "<th>Email</th>";
echo "<th>Action</th>";
echo "</tr>";
$i = 0;
while ($row = mysqli_fetch_array($q)) {
    $i++;
    echo "<tr>";
    echo "<td>$i</td>";
    echo "<td>{$row['st_name']}</td>";
    echo "<td>{$row['st_fname']}</td>";
    echo "<td>{$row['st_address']}</td>";
    echo "<td>{$row['st_gender']}</td>";
    echo "<td>{$row['st_state']}</td>";
    echo "<td>{$row['st_city']}</td>";
    echo "<td>{$row['st_dob']}</td>";
    echo "<td>{$row['st_pincode']}</td>";
    echo "<td>{$row['st_course']}</td>";
    echo "<td>{$row['st_email']}</td>";
    
    echo "<td><a href = 'delete.php?deleteid={$row['st_no']}'>Delete</a></td>";
    echo "</tr>";
    
    }
    
    echo "</table>";
    
  echo "<a href='index.php'>Add Record</a>"; 